package com.cg.sprint.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sprint.bean.Show;
import com.cg.sprint.service.ShowService;
@RestController
public class ShowController 
{
	
	@Autowired
	ShowService showService;
	public void setShowService(ShowService showService)
	{
		this.showService=showService;
	}
	
	@GetMapping(value="/getShow/{showId}",produces="application/json")
	   public ResponseEntity<Optional<Show>> getShow(@PathVariable int showId)
	   {
	 	  Optional<Show> show =  showService.getShow(showId);
	 	  if(show.isPresent())
	 		  return new ResponseEntity<Optional<Show>>(show,HttpStatus.OK);
	 	  return new ResponseEntity<Optional<Show>>(show,HttpStatus.NOT_FOUND);
	   }
            
  /*
   @GetMapping("/getShows")
   public List<Show> getShows()
   {
	   return showService.getShows();
   }
   */
   @PostMapping(value="/addShow",consumes="application/json")
   public ResponseEntity<String> insertShow(@RequestBody()Show show)
   {
	   String message="Show Inserted Successfully";
	   if(show.getTheater()==null || show.getMovie()==null)
		   message="Movie Insertion Failed";
	   else
		 if(showService.insertShow(show)==null)
		   message="Movie Insertion Failed";
	   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
   }
   @DeleteMapping("/deleteShow/{showId}")
   public String deleteShow(@PathVariable int showId)
   {
	   return showService.deleteShow(showId); 
   }

}
