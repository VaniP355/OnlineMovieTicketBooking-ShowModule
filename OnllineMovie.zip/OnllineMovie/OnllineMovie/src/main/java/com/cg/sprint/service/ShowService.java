package com.cg.sprint.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.sprint.bean.Show;
import com.cg.sprint.dao.ShowDAO;
@Service
public class ShowService 
{
	@Autowired
    ShowDAO sdao;
    public void setSdao(ShowDAO sdao) 
    {
    	this.sdao=sdao;
    }
    @Transactional
    public Show insertShow(Show show)
    {
        return sdao.save(show);
    }
    @Transactional(readOnly=true)
    public Optional<Show> getShow(int showId)
    {
    	return sdao.findById(showId);
    }
   
    public List<Show> getShows()
    {
    	return sdao.findAll();
    }
    public String deleteShow(int showId)
    {
    	sdao.deleteById(showId);
    	return "Show Deleted Successfully";
    }

}
