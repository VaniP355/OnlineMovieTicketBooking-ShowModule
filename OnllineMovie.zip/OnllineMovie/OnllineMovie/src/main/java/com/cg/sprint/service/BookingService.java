package com.cg.sprint.service;

public class BookingService {

}
