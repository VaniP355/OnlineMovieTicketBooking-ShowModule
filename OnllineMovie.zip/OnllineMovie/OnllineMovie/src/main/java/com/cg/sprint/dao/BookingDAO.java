package com.cg.sprint.dao;

public class BookingDAO {

}
