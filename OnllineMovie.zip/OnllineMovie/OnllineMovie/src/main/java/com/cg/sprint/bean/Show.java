package com.cg.sprint.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
import javax.persistence.OneToOne;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.sprint.service.MovieService;
import com.cg.sprint.service.TheaterService;

@Entity
public class Show 
{
	@Id
	@Column(name="show_id")
     int showId;
	@Column(name="show_start_time")
     String showStartTime;
	@Column(name="show_end_time")
     String showEndTime;
	@Column(name="show_name")
     String showName;
	@OneToOne
	@JoinColumn(name="movie_id")
	Movie movie;
	@OneToOne
	@JoinColumn(name="theater_id")
    Theater theater;
	public Show() {	}
	public Show(int showId, String showStartTime, String showEndTime, String showName, Movie movie, Theater theater) {
		super();
		this.showId = showId;
		this.showStartTime = showStartTime;
		this.showEndTime = showEndTime;
		this.showName = showName;
		this.movie = movie;
		this.theater = theater;
	}
	public int getShowId() {
		return showId;
	}
	public void setShowId(int showId) {
		this.showId = showId;
	}
	public String getShowStartTime() {
		return showStartTime;
	}
	public void setShowStartTime(String showStartTime) {
		this.showStartTime = showStartTime;
	}
	public String getShowEndTime() {
		return showEndTime;
	}
	public void setShowEndTime(String showEndTime) {
		this.showEndTime = showEndTime;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	public Theater getTheater() {
		return theater;
	}
	public void setTheater(Theater theater) {
		this.theater = theater;
	}
	
	
	
	
	
	
}
