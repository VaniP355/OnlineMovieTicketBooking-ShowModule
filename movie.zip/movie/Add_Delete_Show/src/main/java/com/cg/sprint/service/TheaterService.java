package com.cg.sprint.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.bean.Theater;
import com.cg.sprint.dao.TheaterDAO;

@Service
public class TheaterService 
{
	    @Autowired
	    TheaterDAO tdao;
	    public void setTdao(TheaterDAO tdao) 
	    {
	    	this.tdao=tdao;
	    }
	    @Transactional
	    public Theater insertTheater(Theater theater)
	    {
	        return tdao.save(theater);
	    }
	    @Transactional(readOnly=true)
	    public Theater getTheater(int theaterId)
	    {
	    	return tdao.findById(theaterId).get();
	    }
	   /* 
	    public List<Theater> getTheaters()
	    {
	    	return tdao.findAll();
	    }*/
	    public String deleteTheater(int theaterId)
	    {
	    	tdao.deleteById(theaterId);
	    	return "Theater Deleted Successfully";
	    }
	}

