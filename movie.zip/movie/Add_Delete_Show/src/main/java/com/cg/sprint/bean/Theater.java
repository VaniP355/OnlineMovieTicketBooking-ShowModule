package com.cg.sprint.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class Theater
{
	 @Id	
	@Column(name="theater_id")
    int theaterId;
	@Column(name="theater_name")
    String theaterName;
	@Column(name="theater_city")
    String theaterCity;
	@OneToOne
	@JoinColumn(name="movie_name")
    Movie movie;
	@Column(name="manager_name")
    String managerName;
	@Column(name="manager_contact_details")
    String managerContactDetails;
	public Theater() {}
	public Theater(int theaterId, String theaterName, String theaterCity, Movie movie, String managerName,
			String managerContactDetails) {
		this.theaterId = theaterId;
		this.theaterName = theaterName;
		this.theaterCity = theaterCity;
		this.movie = movie;
		this.managerName = managerName;
		this.managerContactDetails = managerContactDetails;
	}
	public int getTheaterId() {
		return theaterId;
	}
	public void setTheaterId(int theaterId) {
		this.theaterId = theaterId;
	}
	public String getTheaterName() {
		return theaterName;
	}
	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}
	public String getTheaterCity() {
		return theaterCity;
	}
	public void setTheaterCity(String theaterCity) {
		this.theaterCity = theaterCity;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovieName(Movie movie) {
		this.movie = movie;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getManagerContactDetails() {
		return managerContactDetails;
	}
	public void setManagerContactDetails(String managerContactDetails) {
		this.managerContactDetails = managerContactDetails;
	}   
}
