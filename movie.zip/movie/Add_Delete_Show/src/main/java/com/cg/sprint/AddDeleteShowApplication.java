package com.cg.sprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddDeleteShowApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddDeleteShowApplication.class, args);
	}

}
