package com.cg.sprint.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.sprint.bean.Theater;
import com.cg.sprint.service.TheaterService;

@RestController  
public class TheaterController 
{
		@Autowired
		TheaterService theaterService;
		public void setTheaterService(TheaterService theaterService)
		{
			this.theaterService=theaterService;
		}
		
	   @GetMapping("/getTheater/{theaterId}")
	   public Theater getTheater(@PathVariable int theaterId)
	   {
		   return theaterService.getTheater(theaterId);
	   }
	   
	  /*
	   @GetMapping("/getTheaters")
	   public List<Theater> getTheaters()
	   {
		   return theaterService.getTheaters();
	   }
	   */
	   @PostMapping(value="/addtheater",consumes="application/json")
	   public ResponseEntity<String> insertTheater(@RequestBody()Theater theater)
	   {
		   String message="Theater Inserted Successfully";
		   if(theaterService.insertTheater(theater)==null)
			   message="Theater Insertion Failed";
		   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	   }
	   @DeleteMapping("/deleteTheater/{theaterId}")
	   public String deleteTheater(@PathVariable int theaterId)
	   {
		   return theaterService.deleteTheater(theaterId); 
	   }
	}
	  
