package com.cg.sprint.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.sprint.bean.Show;
import com.cg.sprint.service.ShowService;
                    
@RestController 
public class ShowController 
{
		@Autowired
		ShowService showService;
		public void setShowService(ShowService showService)
		{
			this.showService=showService;
		}
		
	   @GetMapping("/getShow/{showId}")
	   public Show getShow(@PathVariable int showId)
	   {
		   return showService.getShow(showId);
	   }
	            
	  /*
	   @GetMapping("/getShows")
	   public List<Show> getShows()
	   {
		   return showService.getShows();
	   }
	   */
	   @PostMapping(value="/addShow",consumes="application/json")
	   public ResponseEntity<String> insertShow(@RequestBody()Show show)
	   {
		   String message="Show Inserted Successfully";
		   if(showService.insertShow(show)==null)
			   message="Movie Insertion Failed";
		   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	   }
	   @DeleteMapping("/deleteShow/{showId}")
	   public String deleteShow(@PathVariable int showId)
	   {
		   return showService.deleteShow(showId); 
	   }
	}
	  
