package com.cg.sprint.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.dao.MovieDAO;
import com.cg.sprint.bean.Movie;
@Service
	public class MovieService 
	{
	    @Autowired
	    MovieDAO mdao;
	    public void setMdao(MovieDAO mdao) 
	    {
	    	this.mdao=mdao;
	    }
	    @Transactional
	    public Movie insertMovie(Movie movie)
	    {
	        return mdao.save(movie);
	    }
	    @Transactional(readOnly=true)
	    public Movie getMovie(int movieId)
	    {
	    	return mdao.findById(movieId).get();
	    }
	   /* 
	    public List<Book> getBooks()
	    {
	    	return bdao.findAll();
	    }*/
	    public String deleteMovie(int movieId)
	    {
	    	mdao.deleteById(movieId);
	    	return "Movie Deleted Successfully";
	    }
	}

