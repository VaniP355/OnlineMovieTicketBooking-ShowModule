	package com.cg.sprint.service;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.dao.ShowDAO;
import com.cg.sprint.bean.Show;
	@Service
		public class ShowService 
		{
		    @Autowired
		    ShowDAO sdao;
		    public void setSdao(ShowDAO sdao) 
		    {
		    	this.sdao=sdao;
		    }
		    @Transactional
		    public Show insertShow(Show show)
		    {
		        return sdao.save(show);
		    }
		    @Transactional(readOnly=true)
		    public Show getShow(int showId)
		    {
		    	return sdao.findById(showId).get();
		    }
		   /* 
		    public List<Book> getShows()
		    {
		    	return sdao.findAll();
		    }*/
		    public String deleteShow(int showId)
		    {
		    	sdao.deleteById(showId);
		    	return "Show Deleted Successfully";
		    }
		}

