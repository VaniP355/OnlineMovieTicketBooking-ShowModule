package com.cg.sprint.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.dao.ScreenDAO;
import com.cg.sprint.dto.Screen;
@Service
public class ScreenService 
{
	@Autowired
    ScreenDAO sDao;
    public void setsDao(ScreenDAO sDao) { this.sDao=sDao;}
    
    @Transactional(readOnly=true)
    public Optional<Screen> getScreen(int screenId)
    {
   	  return sDao.findById(screenId);
    }
    @Transactional(readOnly=true)
    public List<Screen> getScreens()
    {
   	 return sDao.findAll();
    }
    @Transactional
    public void insertScreen(Screen screen)
    {
   	  sDao.save(screen);
    }
    @Transactional
    public void deleteScreen(int screenId)
    {
   	  sDao.deleteById(screenId);
    }

}
