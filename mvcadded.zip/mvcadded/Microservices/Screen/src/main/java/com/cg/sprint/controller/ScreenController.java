package com.cg.sprint.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.sprint.dto.Screen;
import com.cg.sprint.service.ScreenService;
@RestController
public class ScreenController 
{
	@Autowired ScreenService screenService;
    public void setScreenService(ScreenService screenService)
    {
    	this.screenService=screenService;
    }
    
    @GetMapping(value="/getScreen/{screenId}",produces="application/json")
    public ResponseEntity<Optional<Screen>> getScreenDetails(@PathVariable int screenId)
    {
    	Optional<Screen> screen = screenService.getScreen(screenId);
    	if(screen.isPresent())
    		return new ResponseEntity<Optional<Screen>>(screen,HttpStatus.OK);
    	return new ResponseEntity<Optional<Screen>>(screen,HttpStatus.NOT_FOUND);
    }
    
    @GetMapping(value="/getScreens",produces="application/json")
    public List<Screen> getScreensDetails()
    {
    	return screenService.getScreens();
    }
    
    @PostMapping(value="/addScreen",consumes="application/json")
    public ResponseEntity<String> addScreen(@RequestBody() Screen screen)
    {
    	 try
    	 {
    		 screenService.insertScreen(screen);
    		 return new ResponseEntity<String>("Screen Details Added",HttpStatus.OK);
    	 }
    	 catch(Exception ex)
    	 {
    		 return new ResponseEntity<String>("Screen Details Cannot be Added",HttpStatus.BAD_REQUEST);
    	 }
    }
    
    @DeleteMapping("/deleteScreen/{showId}")
    public ResponseEntity<String> deleteScreen(int screenId)
    {
    	 try
    	 {
    		 screenService.deleteScreen(screenId);
    		 return new ResponseEntity<String>("Screen Details Deleted",HttpStatus.OK);
    	 }
    	 catch(Exception ex)
    	 {
    		 return new ResponseEntity<String>("Screen Details Cannot be Deleteed",HttpStatus.BAD_REQUEST);
    	 }
    }

}
