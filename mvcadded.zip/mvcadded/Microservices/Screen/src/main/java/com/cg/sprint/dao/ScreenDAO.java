package com.cg.sprint.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.sprint.dto.Screen;
public interface ScreenDAO extends JpaRepository<Screen, Integer>
{

}
