package com.cg.sprint.dto;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="screendetails")
public class Screen 
{
    @Id
    @Column(name="screen_id")
	int screenId;
    @Column(name="screen_No")
    int screenNo;
    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="screen_id")
    List<Show> shows;
    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="screen_id")
    List<Class> classes;
    public Screen() {}
	public Screen(int screenId, int screenNo, List<Show> shows,List<Class> classes) 
	{
		this.screenId = screenId; this.screenNo = screenNo;	this.shows = shows; this.classes=classes;
	}
	public int getScreenId() {
		return screenId;
	}
	public void setScreenId(int screenId)
	{
		this.screenId = screenId;
	}
	public int getScreenNo() 
	{
		return screenNo;
	}
	public void setScreenNo(int screenNo)
	{
		this.screenNo = screenNo;
	}
	public List<Show> getShows() {
		return shows;
	}
	public void setShows(List<Show> shows) {
		this.shows = shows;
	}
	public List<Class> getClasses() {
		return classes;
	}
	public void setClasses(List<Class> classes) {
		this.classes = classes;
	}
}

