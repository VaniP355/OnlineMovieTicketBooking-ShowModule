package com.cg.sprint.dto;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="theatredetails")
public class Theatre 
{
    @Id
    @Column(name="theatre_id")
    int theatreId;
    @Column(name="theatre_name")
    String theatreName;
    @Column(name="theatre_location")
    String theatreLocation;
    @Column(name="theatre_city")
    String city;
    @Column(name="theatre_contact")
    long contact;
    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="theatre_id")
    List<Screen> screens;
    public Theatre() 
    {
    }
	public Theatre(int theatreId, String theatreName, String theatreLocation, String city, long contact,List<Screen> screens) 
	{
		this.theatreId = theatreId;		this.theatreName = theatreName;		this.theatreLocation = theatreLocation;
		this.city = city;		this.contact = contact;		this.screens = screens;
	}
	public int getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public String getTheatreLocation() {
		return theatreLocation;
	}
	public void setTheatreLocation(String theatreLocation) {
		this.theatreLocation = theatreLocation;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public List<Screen> getScreens() {
		return screens;
	}
	public void setScreens(List<Screen> screens) {
		this.screens = screens;
	}
}
