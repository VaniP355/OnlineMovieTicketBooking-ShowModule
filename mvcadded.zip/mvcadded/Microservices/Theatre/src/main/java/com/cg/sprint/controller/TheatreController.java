package com.cg.sprint.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.sprint.dto.Theatre;
import com.cg.sprint.service.TheatreService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class TheatreController 
{
    @Autowired TheatreService theatreService;
    public void setTheatreService(TheatreService theatreService)
    {
    	this.theatreService=theatreService;
    }
    @GetMapping(value="/getTheatre/{theatreId}",produces="application/json")
    public ResponseEntity<Optional<Theatre>> getTheatreDetails(@PathVariable int theatreId)
    {
    	Optional<Theatre> theatre = theatreService.getTheatre(theatreId);
    	if(theatre.isPresent())
    		return new ResponseEntity<Optional<Theatre>>(theatre,HttpStatus.OK);
    	return new ResponseEntity<Optional<Theatre>>(theatre,HttpStatus.NOT_FOUND);
    }
    @GetMapping(value="/getTheatres",produces="application/json")
    public List<Theatre> getTheatresDetails()
    {
    	return theatreService.getTheatres();
    }
    @PostMapping(value="/addTheatre",consumes="application/json")
    public ResponseEntity<String> addTheatre(@RequestBody() Theatre theatre)
    {
    	 try
    	 {
    		 theatreService.insertTheatre(theatre);
    		 return new ResponseEntity<String>("Theatre Details Added",HttpStatus.OK);
    	 }
    	 catch(Exception ex)
    	 {
    		 return new ResponseEntity<String>("Theatre Details Cannot be Added",HttpStatus.BAD_REQUEST);
    	 }
    }   
    @DeleteMapping("/deleteTheatre/{theatreId}")
    public ResponseEntity<String> deleteTheatre(int theatreId)
    {
    	 try
    	 {
    		 theatreService.deleteTheatre(theatreId);
    		 return new ResponseEntity<String>("Theatre Details Deleted",HttpStatus.OK);
    	 }
    	 catch(Exception ex)
    	 {
    		 return new ResponseEntity<String>("Theatre Details Cannot be Deleteed",HttpStatus.BAD_REQUEST);
    	 }
    }   
}