package com.cg.sprint.dao;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.sprint.dto.Theatre;
public interface TheatreDAO extends JpaRepository<Theatre,Integer>
{
	public Optional<Theatre> findByCity(String city);
}