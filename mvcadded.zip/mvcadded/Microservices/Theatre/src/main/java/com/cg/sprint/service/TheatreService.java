package com.cg.sprint.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.dao.TheatreDAO;
import com.cg.sprint.dto.Theatre;
@Service
public class TheatreService 
{
     @Autowired
     TheatreDAO tDao;
     public void settDao(TheatreDAO tDao) { this.tDao=tDao;}
     
     @Transactional(readOnly=true)
     public Optional<Theatre> getTheatre(int theatreId)
     {
    	 return tDao.findById(theatreId);
     }
     
     @Transactional(readOnly=true)
     public List<Theatre> getTheatres()
     {
    	 return tDao.findAll();
     }
     
     @Transactional
     public void insertTheatre(Theatre theatre)
     {
    	  tDao.save(theatre);
     }
     
     @Transactional
     public void deleteTheatre(int theatreId)
     {
    	 tDao.deleteById(theatreId);
     }
}
