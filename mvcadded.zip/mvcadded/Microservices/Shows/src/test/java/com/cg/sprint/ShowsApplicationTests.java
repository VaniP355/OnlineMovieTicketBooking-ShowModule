package com.cg.sprint;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.cg.sprint.dto.Show;
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
class ShowsApplicationTests 
{
	@Autowired
	TestRestTemplate testRestTemplate;
	public void setTestRestTemplate(TestRestTemplate testRestTemplate)
	{
		this.testRestTemplate=testRestTemplate;
	}
	@LocalServerPort
	int localServerPort;
	@Test
	public void testGetShowDetails_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getShowDetails/1001";
		 ResponseEntity<Show> show = testRestTemplate.getForEntity(url,Show.class);
		 Assertions.assertEquals(200, show.getStatusCodeValue());
	}
	@Test
	public void testGetShowDetails_Negative() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getShowDetails/1001";
		 ResponseEntity<Show> show = testRestTemplate.getForEntity(url,Show.class);
		 Assertions.assertEquals(404, show.getStatusCodeValue());
	}
	/*@Test
	public void testAddShow_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"addShow";
		 Show show = new Show(1001,"Matinee","12:00:00PM",);
		 ResponseEntity<String> response = testRestTemplate.postForEntity(url,show,String.class);
		 Assertions.assertEquals(200, response.getStatusCodeValue());
	}*/
	@Test
	void contextLoads() {
	}

}
