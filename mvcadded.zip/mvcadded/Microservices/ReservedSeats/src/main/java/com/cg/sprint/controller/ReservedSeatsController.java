package com.cg.sprint.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.sprint.dto.ReservedSeats;
import com.cg.sprint.service.ReservedSeatsService;
@RestController
public class ReservedSeatsController 
{
		@Autowired ReservedSeatsService rsService;
	    public void setReservedSeatsService(ReservedSeatsService rsService)
	    {
	    	this.rsService=rsService;
	    }
	    
	    @GetMapping(value="/getReservedSeat/{rsId}",produces="application/json")
	    public ResponseEntity<Optional<ReservedSeats>> getReservedSeat(@PathVariable int rsId)
	    {
	    	Optional<ReservedSeats> reservedSeats = rsService.getReservedSeat(rsId);
	    	if(reservedSeats.isPresent())
	    		return new ResponseEntity<Optional<ReservedSeats>>(reservedSeats,HttpStatus.OK);
	    	return new ResponseEntity<Optional<ReservedSeats>>(reservedSeats,HttpStatus.NOT_FOUND);
	    }
	    
	    @GetMapping(value="/getReservedSeats",produces="application/json")
	    public List<ReservedSeats> getReservedSeatsDetails()
	    {
	    	return rsService.getReservedSeats();
	    }
	    
	    @PostMapping(value="/addReservedSeats",consumes="application/json")
	    public ResponseEntity<String> addReservedSeats(@RequestBody() ReservedSeats reservedSeats)
	    {
	    	 try
	    	 {
	    		 rsService.insertReservedSeats(reservedSeats);
	    		 return new ResponseEntity<String>("ReservedSeat Details Added",HttpStatus.OK);
	    	 }
	    	 catch(Exception ex)
	    	 {
	    		 return new ResponseEntity<String>("ReservedSeat Details Cannot be Added",HttpStatus.BAD_REQUEST);
	    	 }
	    }
	    
	    @DeleteMapping("/deleteReservedSeat/{showId}")
	    public ResponseEntity<String> deleteReservedSeats(int rsId)
	    {
	    	 try
	    	 {
	    		 rsService.deleteReservedSeats(rsId);
	    		 return new ResponseEntity<String>("ReservedSeat Details Deleted",HttpStatus.OK);
	    	 }
	    	 catch(Exception ex)
	    	 {
	    		 return new ResponseEntity<String>("Reserved Details Cannot be Deleteed",HttpStatus.BAD_REQUEST);
	    	 }
	    }

}