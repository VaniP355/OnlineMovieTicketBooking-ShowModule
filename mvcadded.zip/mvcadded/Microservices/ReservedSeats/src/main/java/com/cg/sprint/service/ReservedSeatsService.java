package com.cg.sprint.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.dao.ReservedSeatsDAO;
import com.cg.sprint.dto.ReservedSeats;
@Service
public class ReservedSeatsService 
{
		@Autowired
	    ReservedSeatsDAO rsDao;
	    public void setrsDao(ReservedSeatsDAO rsDao) { this.rsDao=rsDao;}
	    
	    @Transactional(readOnly=true)
	    public Optional<ReservedSeats> getReservedSeat(int rsId)
	    {
	   	  return rsDao.findById(rsId);
	    }
	    @Transactional(readOnly=true)
	    public List<ReservedSeats> getReservedSeats()
	    {
	   	 return rsDao.findAll();
	    }
	    @Transactional
	    public void insertReservedSeats(ReservedSeats reservedSeats)
	    {
	   	  rsDao.save(reservedSeats);
	    }
	    @Transactional
	    public void deleteReservedSeats(int rsId)
	    {
	   	  rsDao.deleteById(rsId);
	    }

	}