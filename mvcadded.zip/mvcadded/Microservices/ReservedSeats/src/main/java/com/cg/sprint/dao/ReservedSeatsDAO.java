package com.cg.sprint.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.sprint.dto.ReservedSeats;
public interface ReservedSeatsDAO extends JpaRepository<ReservedSeats, Integer>
{
}