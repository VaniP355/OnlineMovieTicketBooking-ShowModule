package com.cg.sprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
