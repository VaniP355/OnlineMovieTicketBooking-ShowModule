package com.cg.sprint.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.sprint.dto.Class;
import com.cg.sprint.service.ClassService;
@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ClassController 
{
	@Autowired ClassService classService;
    public void setClassService(ClassService classService)
    {
    	this.classService=classService;
    }
    @GetMapping(value="/getClass/{classId}",produces="application/json")
    public ResponseEntity<Optional<Class>> getClassDetails(@PathVariable int classId)
    {
    	Optional<Class> c = classService.getClass(classId);
    	if(c.isPresent())
    		return new ResponseEntity<Optional<Class>>(c,HttpStatus.OK);
    	return new ResponseEntity<Optional<Class>>(c,HttpStatus.NOT_FOUND);
    }
    @GetMapping(value="/getClasses",produces="application/json")
    public List<Class> getClassDetails()
    {
    	return classService.getClasses();
    }
    @PostMapping(value="/addClass",consumes="application/json")
    public ResponseEntity<String> addClass(@RequestBody() Class c)
    {
    	 try
    	 {
    		 classService.insertClass(c);
    		 return new ResponseEntity<String>("Class Details Added",HttpStatus.OK);
    	 }
    	 catch(Exception ex)
    	 {
    		 return new ResponseEntity<String>("Class Details Cannot be Added",HttpStatus.BAD_REQUEST);
    	 }
    }
    
    @DeleteMapping("/deleteClass/{classId}")
    public ResponseEntity<String> deleteClass(int classId)
    {
    	 try
    	 {
    		 classService.deleteClass(classId);
    		 return new ResponseEntity<String>("Class Details Deleted",HttpStatus.OK);
    	 }
    	 catch(Exception ex)
    	 {
    		 return new ResponseEntity<String>("Class Details Cannot be Deleteed",HttpStatus.BAD_REQUEST);
    	 }
    }
}