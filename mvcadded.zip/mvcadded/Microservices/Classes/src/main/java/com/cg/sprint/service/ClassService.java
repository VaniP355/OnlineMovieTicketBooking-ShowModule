package com.cg.sprint.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.dao.ClassDAO;
import com.cg.sprint.dto.Class;
@Service
public class ClassService 
{
	@Autowired
	ClassDAO cDao;
	public void setcDao(ClassDAO cDao) 
	{ 
		this.cDao=cDao;
	}
    @Transactional(readOnly=true)
    public Optional<Class> getClass(int classId)
    {
   	  return cDao.findById(classId);
    }
    @Transactional(readOnly=true)
    public List<Class> getClasses()
    {
   	 return cDao.findAll();
    }
    @Transactional
    public void insertClass(Class c)
    {
   	  cDao.save(c);
    }
    
    @Transactional
    public void deleteClass(int classId)
    {
   	  cDao.deleteById(classId);
    }
}