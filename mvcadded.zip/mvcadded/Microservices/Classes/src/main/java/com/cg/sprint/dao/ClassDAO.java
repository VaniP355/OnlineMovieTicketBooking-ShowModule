package com.cg.sprint.dao;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.sprint.dto.Class;
public interface ClassDAO extends JpaRepository<Class, Integer>
{

}