package com.cg.sprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
@EnableEurekaServer
@SpringBootApplication
public class OnlineMovieEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMovieEurekaApplication.class, args);
	}

}
